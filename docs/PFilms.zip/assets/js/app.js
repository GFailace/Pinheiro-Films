M.AutoInit()

$(document).ready(function () {
    $('.sidenav').sidenav();
});

$('.carousel.carousel-slider').carousel({
    fullWidth: false,
    duration: 200,
    indicators: true
  });

  $(document).ready(function(){
    $('.slider').slider();
  });